function init(){
	alert("invoking init");
	$("#btn1").bind("click mouseleave",function()
			{
			alert("Event occurs");
			});
	$("#btn2").bind("click",function()
			{
			$("#btn1").unbind("click");
			});
	$("#btn3").bind("click",function()
			{
			$("#btn1").unbind("mouseleave");
			});
	
}